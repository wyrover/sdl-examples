// ------------------------------------------------------------
// The Breakout Tutorial
// (c) 2015 Rembound.com
// http://rembound.com/articles/the-breakout-tutorial
// ------------------------------------------------------------

#ifndef MAIN_H_
#define MAIN_H_

#include "game.h"

int main(int argc, char* argv[]);

#endif
