The Breakout Tutorial
(c) 2015 Rembound.com
http://rembound.com/articles/the-breakout-tutorial

Building a Breakout game with SDL 2.0.