// ------------------------------------------------------------
// Porting Pong From Flash To C++
// http://rembound.com/articles/porting-pong-from-flash-to-cpp
// (c) 2014 Rembound.com
// ------------------------------------------------------------

#ifndef MAIN_H_
#define MAIN_H_

#include "game.h"

int main(int argc, char* argv[]);

#endif
