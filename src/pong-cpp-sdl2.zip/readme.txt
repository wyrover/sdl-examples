Porting Pong From Flash To C++
(c) 2014 Rembound.com
http://rembound.com/articles/porting-pong-from-flash-to-cpp

Porting a Flash game to C++.